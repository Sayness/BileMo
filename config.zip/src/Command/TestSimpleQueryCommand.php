<?php
namespace App\Command;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(
    name: 'app:test-simple-query',
    description: 'Test a simple Doctrine query.',
)]
class TestSimpleQueryCommand extends Command
{
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $connection = $this->entityManager->getConnection();
        $query = 'SELECT id, name, email FROM "user"';
        $stmt = $connection->prepare($query);
        $result = $stmt->executeQuery()->fetchAllAssociative();

        $output->writeln('Query result: ' . json_encode($result));

        return Command::SUCCESS;
    }
}
